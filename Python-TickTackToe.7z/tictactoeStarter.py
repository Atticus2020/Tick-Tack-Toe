#Complete a game of tic-tac-toe using the starter code below.

#Requirements
#! 1. Two players should be able to play as many games as desired and keep score of wins
#! 2. The "New Game" button terminates the current game and resets the playing surface
#! 3. The "Quit Game" button exits the entire program
#! 4. Player "X" always starts the first game
#! 5. A new game begins immediately after a draw or a winner.
# !6. The winner of the previous game gets to move first in the next game.  If the
#!    previous game was a draw or "New Game" was pressed, the first move should be taken 
# !   by the player who went second in the previous game
#! 8. The game play board should accurately reset when a new game is started

from graphics import *
from button import Button

####All Global Values and Graphics Creation####

#Game Variables
p1TurnTrue = True
p2TurnTrue = False
p1Wins = False
p2Wins = False
winner = ""
loser = "O"
p1Score = 0
p2Score = 0
currentPlayer = "X"
colorSwapRule = 1
onePass = False

#Sqaure Variables
one = 0
two = 0
three = 0
four = 0
five = 0
six = 0
seven = 0
eight = 0
nine = 0

#Graphics Variables
scoreboardHeight = 35
winHeight = 380
winWidth = 320
winMargin = 10
columnWidth = 100
rowHeight= 100

#GRAPHICS
win = GraphWin("Tic-Tac-Toe!", winWidth,winHeight)
y = 120

xScoreboard = Text(Point(60,scoreboardHeight - 15),"P1 Wins: " + str(p1Score))
xScoreboard.draw(win)

yScoreboard = Text(Point(60,scoreboardHeight),"P2 Wins: " + str(p2Score))
yScoreboard.draw(win)

nextPlayer = Text (Point(60,scoreboardHeight + 15),"Next up: " + currentPlayer)
nextPlayer.draw(win)

newGame = Button(win,Point(160,scoreboardHeight),85,30,"New Game")
newGame.activate()
ngPoint = Point(160,scoreboardHeight)

quitGame = Button(win,Point(260,scoreboardHeight),85,30,"Quit Game")
quitGame.activate()

rows = []
for r in range(3):
    rows.append([])
    x = winMargin + (columnWidth // 2)
    
    for c in range(3):
        rows[r].append(Button(win,Point(x,y),columnWidth,rowHeight,""))
        rows[r][c].activate()
        x = x + columnWidth
    y = y + rowHeight
    
def redrawScoreboardP1():
    global xScoreboard
    
    xScoreboard.undraw()
    xScoreboard = Text(Point(60,scoreboardHeight - 15),"P1 Wins: " + str(p1Score))
    xScoreboard.draw(win)
def redrawScoreboardP2():
    global yScoreboard
    
    yScoreboard.undraw()
    yScoreboard = Text(Point(60,scoreboardHeight),"P2 Wins: " + str(p2Score))
    yScoreboard.draw(win)
    

    
def gameLogic():
    global buttonsClicked
    global currentPlayer
    global nextPlayer
    global one, two, three, four, five, six, seven, eight, nine
    global winner
    global loser

    buttonsClicked = 0
    p1Wins = False
    p2Wins = False
    
    #Game Logic
    while True:
        currMouse = win.getMouse()
        p = Point(currMouse.x, currMouse.y)

        #New Game Button
        if newGame.clicked(p):
            startNewGame()
            break
        #Quit Game Button
        if quitGame.clicked(p):
            win.close()
            break
            
        #1 - #9 Buttons
        if rows[0][0].clicked(p):
            rows[0][0].deactivate()
            swapPlayers()
            if currentPlayer == "X":
                rows[0][0].deactivateP2()
                one = 1
                
            if currentPlayer == "O":
                rows[0][0].deactivateP1()
                one = 2
            buttonsClicked += 1
            
        if rows[0][1].clicked(p):
            rows[0][1].deactivate()
            swapPlayers()
            if currentPlayer == "X":
                rows[0][1].deactivateP2()
                two = 1
                
            if currentPlayer == "O":
                rows[0][1].deactivateP1()
                two = 2
            buttonsClicked += 1
            
        if rows[0][2].clicked(p):
            rows[0][2].deactivate()
            swapPlayers()
            if currentPlayer == "X":
                rows[0][2].deactivateP2()
                three = 1
            if currentPlayer == "O":
                rows[0][2].deactivateP1()
                three = 2
            buttonsClicked += 1
            
        if rows[1][0].clicked(p):
            rows[1][0].deactivate()
            swapPlayers()
            if currentPlayer == "X":
                rows[1][0].deactivateP2()
                four = 1
            if currentPlayer == "O":
                rows[1][0].deactivateP1()
                four = 2
            buttonsClicked += 1
            
        if rows[1][1].clicked(p):
            rows[1][1].deactivate()
            swapPlayers()
            if currentPlayer == "X":
                rows[1][1].deactivateP2()
                five = 1
            if currentPlayer == "O":
                rows[1][1].deactivateP1()
                five = 2
            buttonsClicked += 1
            
        if rows[1][2].clicked(p):
            rows[1][2].deactivate()
            swapPlayers()
            if currentPlayer == "X":
                rows[1][2].deactivateP2()
                six = 1
                
            if currentPlayer == "O":
                rows[1][2].deactivateP1()
                six = 2
            buttonsClicked += 1
            
        if rows[2][0].clicked(p):
            rows[2][0].deactivate()
            swapPlayers()
            if currentPlayer == "X":
                rows[2][0].deactivateP2()
                seven = 1
                
            if currentPlayer == "O":
                rows[2][0].deactivateP1()
                seven = 2
            buttonsClicked += 1
            
        if rows[2][1].clicked(p):
            rows[2][1].deactivate()
            swapPlayers()
            if currentPlayer == "X":
                rows[2][1].deactivateP2()
                eight = 1
                
            if currentPlayer == "O":
                rows[2][1].deactivateP1()
                eight = 2
            buttonsClicked += 1
            
        if rows[2][2].clicked(p):
            rows[2][2].deactivate()
            swapPlayers()
            if currentPlayer == "X":
                rows[2][2].deactivateP2()
                nine = 1
            if currentPlayer == "O":
                rows[2][2].deactivateP1()
                nine = 2
            buttonsClicked += 1
        #Victory Logic
            
        #Horizontal Wins
        if one == 1 & two == 1 & three == 1:
            swapPlayers()
            winner = "X"
            loser = "O"
            p2Win()
            p1Wins = True

            continue
        if one == 2 & two == 2 & three == 2:
            swapPlayers()
            p1Win()
            p2Wins = True
            winner = "O"
            loser = "X"
            continue
        if four == 1 & five == 1 & six == 1:
            swapPlayers()
            p2Win()
            p1Wins = True
            winner = "X"
            loser = "O"
            continue
        if four == 2 & five == 2 & six == 2:
            swapPlayers()
            p1Win()
            p2Wins = True
            winner = "O"
            loser = "X"
            continue
        if seven == 1 & eight == 1 & nine == 1:
            swapPlayers()
            p2Win()
            p1Wins = True
            winner = "X"
            loser = "O"
            continue
        if seven == 2 & eight == 2 & nine == 2:
            swapPlayers()
            p1Win()
            p2Wins = True
            winner = "O"
            loser = "X"
            continue
        #Vertical Wins
        if one == 1 & four == 1 & seven == 1:
            swapPlayers()
            p2Win()
            p1Wins = True
            winner = "X"
            loser = "O"
            continue
        if one == 2 & four == 2 & seven == 2:
            swapPlayers()
            p1Win()
            p2Wins = True
            winner = "O"
            loser = "X"
            continue
        if two == 1 & five == 1 & eight == 1:
            swapPlayers()
            p2Win()
            p1Wins = True
            winner = "X"
            loser = "O"
            continue
        if two == 2 & five == 2 & eight == 2:
            swapPlayers()
            p1Win()
            p2Wins = True
            winner = "O"
            loser = "X"
            continue
        if three == 1 & six == 1 & nine == 1:
            swapPlayers()
            p2Win()
            p1Wins = True
            winner = "X"
            loser = "O"
            continue
        if three == 2 & six == 2 & nine == 2:
            swapPlayers()
            p1Win()
            p2Wins = True
            winner = "O"
            loser = "X"
            continue
        #Diagnal Wins
        if one == 1 & five == 1 & nine == 1:
            swapPlayers()
            p2Win()
            p1Wins = True
            winner = "X"
            loser = "O"
            continue
        if one == 2 & five == 2 & nine == 2:
            swapPlayers()
            p1Win()
            p2Wins = True
            winner = "O"
            loser = "X"
            continue
        if three == 1 & five == 1 & seven == 1:
            swapPlayers()
            p2Win()
            p1Wins = True
            winner = "X"
            loser = "O"
            continue
        if three == 2 & five == 2 & seven == 2:
            swapPlayers()
            p1Win()
            p2Wins = True
            winner = "O"
            loser = "X"
            continue

        #Tie Logic
        if buttonsClicked == 9:
            if p2Wins == False & p1Wins == False:
                
                nextPlayer.undraw()
                nextPlayer = Text (Point(60,scoreboardHeight + 15),"Next up: " + loser)
                nextPlayer.draw(win)
                swapLoser()
                
                
                tieFunction()
                

                
def p1Win():
    global buttonsClicked
    global p1Wins
    global p2Wins
    
    print("Player 1 is Victorous!")
    buttonsClicked = 0
    p1ScoreUp()
    redrawScoreboardP1()
    buttonsClicked = 0
    p1Wins = False
    p2Wins = False
    reactivate()
def p2Win():
    global buttonsClicked
    
    print("Player 2 is Victorous!")
    buttonsClicked = 0
    p2ScoreUp()
    redrawScoreboardP2()
    buttonsClicked = 0
    p1Wins = False
    p2Wins = False
    reactivate()
def tieFunction():
    print("How unfortunate, its a tie!")
    buttonsClicked = 0
    reactivate()
    print("working2")
        
def swapPlayers():
    global nextPlayer
    global currentPlayer
    run = True
    while run == True:

        if currentPlayer == "X":
            currentPlayer = "O"
            
            nextPlayer.undraw()
            nextPlayer = Text (Point(60,scoreboardHeight + 15),"Next up: " + currentPlayer)
            nextPlayer.draw(win)
            break
        
        if currentPlayer == "O":
            currentPlayer = "X"
        
            nextPlayer.undraw()
            nextPlayer = Text (Point(60,scoreboardHeight + 15),"Next up: " + currentPlayer)
            nextPlayer.draw(win)
            break
def swapWinners():
    global nextPlayer
    global winner
    
    nextPlayer.undraw()
    nextPlayer = Text (Point(60,scoreboardHeight + 15),"Next up: " + winner)
    nextPlayer.draw(win)
    
def swapLoser():
    global loser
    global currentPlayer

    while True:
        if loser == "X":
            loser = "O"
            break
        if loser == "O":
            loser = "X"
            break
            
    
    
def reactivate():
    global one, two, three, four, five, six, seven, eight, nine
    rows[0][0].activate()
    rows[0][1].activate()
    rows[0][2].activate()
    rows[1][0].activate()
    rows[1][1].activate()
    rows[1][2].activate()
    rows[2][0].activate()
    rows[2][1].activate()
    rows[2][2].activate()
    one = 0
    two = 0
    three = 0
    four = 0
    five = 0
    six = 0
    seven = 0
    eight = 0
    nine = 0
    gameLogic()
    
def startNewGame():
    global win
    global loser
    global nextPlayer
    global p1Score
    global p2Score
    global one, two, three, four, five, six, seven, eight, nine
    global currentPlayer
    
    rules()
    nextPlayer.undraw()
    nextPlayer = Text (Point(60,scoreboardHeight + 15),"Next up: " + loser)
    nextPlayer.draw(win)
    swapLoser()
    p1TurnTrue = True
    p2TurnTrue = False
    p1Wins = False
    p2Wins = False
    p1Score = 0
    p2Score = 0
    one = 0
    two = 0
    three = 0
    four = 0
    five = 0
    six = 0
    seven = 0
    eight = 0
    nine = 0
    redrawScoreboardP1()
    redrawScoreboardP2()
    reactivate()
    gameLogic()

def p1ScoreUp():
    global p1Score
    p1Score = p1Score + 1
    
def p2ScoreUp():
    global p2Score
    p2Score = p2Score + 1
def rules():
    global colorSwapRule
    global onePass
    while True:
        if onePass == False:
            print("Welcome to Tic Tac Toe!")
            print("Two players rotate their turns")
            print("When it is your turn click a box and attempt to line three boxes horizontally, vertically, or diaglially of your color and you win!")
            onePass = True
    
        if colorSwapRule == 1:
            print("Player 1 is X and Red, Player 2 is O and Blue")
            colorSwapRule = 2
            break
        
        if colorSwapRule == 2:
            print("Player 1 is X and Blue, Player 2 is O and Red")
            colorSwapRule = 1
            break
rules()
gameLogic()
